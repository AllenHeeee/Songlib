package View;
/*
Authors: Junjie He jh1285, Ruimin Li rl751
 */
import Structure.Song;
import Structure.SongList;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ResourceBundle;

public class Controller implements Initializable {    //   修改过
    ObservableList obslist= FXCollections.observableArrayList();
    @FXML Label SongNameShow;
    @FXML TextField SongNameAdd;
    @FXML TextField AritstAdd;
    @FXML TextField AlbumAdd;
    @FXML TextField YearAdd;
    @FXML Label NoticeLabel;
    @FXML ListView<String> SongListUI;
    @FXML TextField SongNameEdit;
    @FXML TextField ArtistEdit;
    @FXML TextField AlbumEdit;
    @FXML TextField YearEdit;
    @FXML Label AuthorShow;
    @FXML Label AlbumShow;
    @FXML Label YearShow;


    public void LastSongTapped(ActionEvent e) {
        if(SongList.list.size()==0){
            return;
        }
        if(SongList.currIndex-1<0){
            return;
        }
        SongList.currIndex--;
        retrieveData(SongList.currIndex);
        SongListUI.getSelectionModel().select(SongList.currIndex);
    }
    public void NextSongTapped(ActionEvent e) {
        if(SongList.list.size()==0){
            return;
        }
        if(SongList.currIndex+1>=SongList.list.size()){
            return;
        }
        SongList.currIndex++;
        retrieveData(SongList.currIndex);
        SongListUI.getSelectionModel().select(SongList.currIndex);
    }

    public void EditTapped(ActionEvent e) {
        if(SongList.list.isEmpty())return;
//    if(SongList.currIndex==-1){
//        showInputError("Edit Failed!","Empty Song list!");
//        NoticeLabel.setText("Edit Failed!");
//        return;
//    }
        Song newSong = new Song(SongNameEdit.getText(),ArtistEdit.getText(),AlbumEdit.getText(),YearEdit.getText());
        if(SongNameEdit.getText().trim().isEmpty()||ArtistEdit.getText().trim().isEmpty()){
            showInputError("Edit Failed!","Empty SongName or Artist!");
            NoticeLabel.setText("Edit Failed!");
            retrieveData(SongList.currIndex);
            return;
        }
        if(!YearEdit.getText().trim().isEmpty()){
            int year=0;
            try {
                year=Integer.parseInt(YearEdit.getText());
            }catch (Exception ex){
                showInputError("Bad Input!","Please change the year!");
                NoticeLabel.setText("Edit Failed!");
                retrieveData(SongList.currIndex);
                return;
            }
            if(year<0||year>2019){
                NoticeLabel.setText("Edit Failed!");
                System.out.println("Edit Failed!");
                showInputError("Edit Failed","Please change the Year!");
                retrieveData(SongList.currIndex);
                return;
            }
        }


        Song temp = SongList.list.remove(SongList.currIndex);
        if(!SongList.addIntoAL(newSong)){
            SongList.addIntoAL(temp);
            System.out.println("Edit Failed!");
            showInputError("Song Existed!","Edit Failed");
            NoticeLabel.setText("Edit Failed!");
            retrieveData(SongList.currIndex);
            return;
        }else{
            int temp2=SongList.currIndex;
            SongListUI.getItems().clear();
            SongList.currIndex=temp2;
            loadData();
            try{
                SongList.loadListIntoFile();
            }catch (Exception ex) {
                System.out.println(ex.toString());
            }
            System.out.println("Edit Succeed!");
            NoticeLabel.setText("Edit Succeed!");
            retrieveData(SongList.currIndex);
        }
    }
    public void DeleteTapped(ActionEvent e) {
        if(SongList.list.isEmpty()){
            return;
        }
        SongList.list.remove(SongList.currIndex);
        int temp=SongList.currIndex;
        SongListUI.getItems().clear();
        SongList.currIndex=temp;

        loadData();

        try{
            SongList.loadListIntoFile();

        }catch (Exception ex) {
            System.out.println(ex.toString());
        }
        if(SongList.currIndex>=SongList.list.size())
        {
            SongList.currIndex--;
        }
        if(SongList.currIndex<0)
        {
            SongNameShow.setText("Song Name");
            AuthorShow.setText("Artist");
            AlbumShow.setText("Album");
            YearShow.setText("Year");
            SongNameEdit.setText("");
            ArtistEdit.setText("");
            AlbumEdit.setText("");
            YearEdit.setText("");
        }else {
            retrieveData(SongList.currIndex);
            SongListUI.getSelectionModel().select(SongList.currIndex);
        }
    }
    public void ChooseTapped(ActionEvent e) {
        SongList.currIndex = SongListUI.getSelectionModel().getSelectedIndex();
        retrieveData(SongList.currIndex);
    }
    public void AddTapped(ActionEvent e) {
        String songname=SongNameAdd.getText();
        String artist=AritstAdd.getText();
        String Album=AlbumAdd.getText();
        int year=0;

        if(songname.trim().isEmpty()){
            NoticeLabel.setText("Add Failed!");
            System.out.println("Add Failed!");
            showInputError("Add Failed","Please change the Song Name!");
            return;
        }
        if(artist.trim().isEmpty()){
            NoticeLabel.setText("Add Failed!");
            System.out.println("Add Failed!");
            showInputError("Add Failed","Please change the Artist Name!");
            return;
        }
        if(!YearAdd.getText().trim().isEmpty()) {
            try {
                year = Integer.parseInt(YearAdd.getText());
            } catch (Exception ex) {
                showInputError("Bad Input!", "Please change the year!");
                NoticeLabel.setText("Add Failed!");
                return;
            }
            if (year < 0 || year > 2019) {
                NoticeLabel.setText("Add Failed!");
                System.out.println("Add Failed!");
                showInputError("Add Failed", "Please change the Year!");
                return;
            }
        }

       if(!SongList.addIntoAL(new Song(songname,artist,Album,YearAdd.getText().trim()))){
           System.out.println("Add Failed!");
           showInputError("Song Existed!","Bad Input");
           NoticeLabel.setText("");
           SongNameAdd.setText("");
           AritstAdd.setText("");
           AlbumAdd.setText("");
           YearAdd.setText("");
           NoticeLabel.setText("Add Failed!");
           return;
       }

        try{
            SongList.loadListIntoFile();
        }catch (Exception ex){
            System.out.println(ex.toString());
        }
        NoticeLabel.setText("");
        SongNameAdd.setText("");
        AritstAdd.setText("");
        AlbumAdd.setText("");
        YearAdd.setText("");
        NoticeLabel.setText("Add Succeed!");
        System.out.println("Add Succeed!");
        int temp=SongList.currIndex;
        SongListUI.getItems().clear();
        SongList.currIndex=temp;    //   从这里开始
        loadData();
        SongNameEdit.setText(songname);
        ArtistEdit.setText(artist);
        AlbumEdit.setText(Album);
        YearEdit.setText(YearAdd.getText().trim());
        SongNameShow.setText(songname);
        AuthorShow.setText("By: "+artist);
        AlbumShow.setText("Album: "+Album);
        YearShow.setText("Year: "+YearAdd.getText().trim());
        SongListUI.getSelectionModel().select(songname+"   By:"+artist);
    }
    public static void showInputError(String header,String mess){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(header);
        alert.setContentText(mess);
        alert.showAndWait();
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try{
            SongList.fildRead();
        }catch (Exception ex){
            System.out.println(ex.toString());
        }
        if(SongList.list.size()!=0){
            loadData();
            SongListUI.getSelectionModel().select(0);
            if(SongList.list.get(0).getSongName()!=null) {
                SongList.currIndex=0;
                /// Edited!
                retrieveData(SongList.currIndex);
            }
        }
        SongListUI.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {

            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                SongList.currIndex = SongListUI.getSelectionModel().getSelectedIndex();
                retrieveData(SongList.currIndex);

            }
        });
    }
    public void retrieveData(int index){
        SongListUI.getSelectionModel().select(SongList.currIndex);
        SongNameEdit.setText(SongList.list.get(index).getSongName());
        SongNameShow.setText(SongList.list.get(index).getSongName());
        ArtistEdit.setText(SongList.list.get(index).getArtist());
        AuthorShow.setText("By: "+SongList.list.get(index).getArtist());
        AlbumEdit.setText(SongList.list.get(index).getAlbum());
        AlbumShow.setText("Album: "+SongList.list.get(index).getAlbum());
        YearEdit.setText(SongList.list.get(index).getYear());
        YearShow.setText("Year: "+SongList.list.get(index).getYear());
    }
    private void loadData(){
        obslist.removeAll(obslist);
        String str=null;
        for(int i=0;i<SongList.list.size();i++)
        {
            str=SongList.list.get(i).getSongName()+"   By:"+SongList.list.get(i).getArtist();
            obslist.add(str);
        }

        SongListUI.getItems().addAll(obslist);
    }
}
