package App;
/*
Authors: Junjie He jh1285, Ruimin Li rl751
 */
import Structure.SongList;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class SongLib extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("../View/UI.fxml"));
        primaryStage.setTitle("Songlib");
        primaryStage.setScene(new Scene(root, 900, 600));
        primaryStage.setResizable(false);
        primaryStage.show();
        primaryStage.setOnCloseRequest(e->closeProgram());
    }

    private void closeProgram(){
        System.out.println("close!!!!!!!");
    }


    public static void main(String[] args) {
        launch(args);
    }
}
